//
// Created by Anders Arnholm on 2020-12-04.
//

#include "pch.h"
#include "../TennisGame//tennis.cpp"

// All test
TEST(AllTest, LoveAll) { EXPECT_EQ("Love-All", Tennis().tennis_score(0, 0)); }
TEST(AllTest, FifteenAll) {	EXPECT_EQ("Fifteen-All", Tennis().tennis_score(1, 1));}
TEST(AllTest, ThirtyAll) { EXPECT_EQ("Thirty-All", Tennis().tennis_score(2, 2)); }
TEST(AllTest, Deuce) { EXPECT_EQ("Deuce", Tennis().tennis_score(3, 3)); }

// differnet score test
TEST(diffTest, LoveFifteen) { EXPECT_EQ("Love-Fifteen", Tennis().tennis_score(0, 1)); }
TEST(diffTest, ThirtyFifteen) { EXPECT_EQ("Thirty-Fifteen", Tennis().tennis_score(2, 1)); }
TEST(diffTest, FourtyThirty) { EXPECT_EQ("Forty-Thirty", Tennis().tennis_score(3, 2)); }

// Advantage test
TEST(AdvtgTest, Advantageplayer1) { EXPECT_EQ("Advantage player1", Tennis().tennis_score(5, 4)); }
TEST(AdvtgTest, Advantageplayer2) { EXPECT_EQ("Advantage player2", Tennis().tennis_score(4, 5)); }
TEST(AdvtgTest, Winforplayer1) { EXPECT_EQ("Win for player1", Tennis().tennis_score(6, 4)); }
TEST(AdvtgTest, Winforplayer2) { EXPECT_EQ("Win for player2", Tennis().tennis_score(4, 6)); }
